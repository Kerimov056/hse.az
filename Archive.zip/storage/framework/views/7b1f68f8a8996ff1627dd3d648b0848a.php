<?php
    // Sosial şəbəkələr
    $fb  = setting('social.facebook');
    $tw  = setting('social.twitter');
    $ig  = setting('social.instagram');
    $pin = setting('social.pinterest'); // fallback üçün saxlayırıq
    $wa  = setting('social.whatsapp');  // tercihen wa.me/…

    // LinkedIn: varsa onu götür, yoxdursa Pinterest URL-ni istifadə et
    $li = setting('social.linkedin', $pin);

    // Linkləri təhlükəsiz açmaq üçün atributlar
    $attrs = 'target="_blank" rel="noopener noreferrer"';

    // Sayt məlumatları
    $siteName = setting('site.name', 'Educve');
    $phone    = setting('site.phone');
    $email    = setting('site.email');
    $address  = setting('site.address');
    $tagline  = setting(
        'site.tagline',
        'Far far away, behind the word mountains, far from the Consonantia, there live the blind texts.'
    );

    // 1) site.logo üstünlük; 2) branding.logo fallback
    $logoPath = setting('site.logo') ?: setting('branding.logo');

    $logoUrl = null;
    if ($logoPath) {
        $logoUrl = \Illuminate\Support\Str::startsWith($logoPath, ['http', '/storage', 'assets/'])
            ? asset($logoPath)
            : asset('storage/' . ltrim($logoPath, '/'));
    }

    // tel: üçün yalnız rəqəm və + saxla
    $telHref = $phone ? 'tel:' . preg_replace('/[^0-9\+]+/', '', $phone) : null;

    // Footer qalereyası üçün son şəkillər (gallery_images cədvəlindən)
    $footerGallery = \App\Models\GalleryImage::query()
        ->latest()
        ->take(6)
        ->get();
?>

<!-- Start Footer Section -->
<footer class="td_footer td_style_1">
    <div class="container">
        <div class="td_footer_row">
            
            <div class="td_footer_col">
                <div class="td_footer_widget">
                    <div class="td_footer_text_widget td_fs_18">
                        <?php if($logoUrl): ?>
                            <img src="<?php echo e($logoUrl); ?>" alt="<?php echo e($siteName); ?>" style="max-height:64px; width:auto;">
                        <?php else: ?>
                            
                            <svg width="241" height="64" viewBox="0 0 241 64" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                
                            </svg>
                        <?php endif; ?>

                        
                        <p><?php echo e($tagline); ?></p>
                    </div>

                    <ul class="td_footer_address_widget td_medium td_mp_0">
                        <?php if($phone && $telHref): ?>
                            <li>
                                <i class="fa-solid fa-phone-volume"></i>
                                <a href="<?php echo e($telHref); ?>"><?php echo e($phone); ?></a>
                            </li>
                            <li>
                                <i class="fa-solid fa-phone-volume"></i>
                                <a href="<?php echo e($telHref); ?>">(+994) 10 253 23 88</a>
                            </li>
                        <?php endif; ?>

                        <?php if($email): ?>
                            <li>
                                <i class="fa-solid fa-envelope"></i>
                                <a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a>
                            </li>
                        <?php endif; ?>

                        <?php if($address): ?>
                            <li>
                                <i class="fa-solid fa-location-dot"></i>
                                <?php echo nl2br(e($address)); ?>

                            </li>
                        <?php endif; ?>
                    </ul>

                    
                    <?php if($fb || $tw || $ig || $li || $wa): ?>
                        <div class="td_footer_social_btns td_fs_20 mt-3">
                            <?php if($fb): ?>
                                <a href="<?php echo e($fb); ?>" class="td_center" <?php echo $attrs; ?>>
                                    <i class="fa-brands fa-facebook-f"></i>
                                </a>
                            <?php endif; ?>

                            <?php if($tw): ?>
                                <a href="<?php echo e($tw); ?>" class="td_center" <?php echo $attrs; ?>>
                                    <i class="fa-brands fa-x-twitter"></i>
                                </a>
                            <?php endif; ?>

                            <?php if($ig): ?>
                                <a href="<?php echo e($ig); ?>" class="td_center" <?php echo $attrs; ?>>
                                    <i class="fa-brands fa-instagram"></i>
                                </a>
                            <?php endif; ?>

                            
                            <?php if($li): ?>
                                <a href="<?php echo e($li); ?>" class="td_center" <?php echo $attrs; ?>>
                                    <i class="fa-brands fa-linkedin-in"></i>
                                </a>
                            <?php endif; ?>

                            <?php if($wa): ?>
                                <a href="<?php echo e($wa); ?>" class="td_center" <?php echo $attrs; ?>>
                                    <i class="fa-brands fa-whatsapp"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            
            <div class="td_footer_col">
                <div class="td_footer_widget">
                    <h2 class="td_footer_widget_title td_fs_32 td_white_color td_medium td_mb_30">
                        <?php echo e(__('Navigateion')); ?>

                    </h2>
                    <ul class="td_footer_widget_menu">
                        <li><a href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a></li>
                        <li><a href="<?php echo e(route('faqss')); ?>"><?php echo e(__('Faqs')); ?></a></li>
                        <li><a href="<?php echo e(route('about')); ?>"><?php echo e(__('About Us')); ?></a></li>
                        <li><a href="<?php echo e(route('resources')); ?>"><?php echo e(__('Resources')); ?></a></li>
                        <li><a href="<?php echo e(route('team')); ?>"><?php echo e(__('Team')); ?></a></li>
                        <li><a href="<?php echo e(route('contact')); ?>"><?php echo e(__('Contact')); ?></a></li>
                    </ul>
                </div>
            </div>

            
            <div class="td_footer_col">
                <div class="td_footer_widget">
                    <h2 class="td_footer_widget_title td_fs_32 td_white_color td_medium td_mb_30">
                        <?php echo e(__('Courses')); ?>

                    </h2>
                    <ul class="td_footer_widget_menu">
                        <li><a href="<?php echo e(route('courses-grid-view')); ?>"><?php echo e(__('Courses')); ?></a></li>
                        <li><a href="<?php echo e(route('services')); ?>"><?php echo e(__('Services')); ?></a></li>
                        <li><a href="<?php echo e(route('topices')); ?>"><?php echo e(__('Topics')); ?></a></li>
                        <li><a href="<?php echo e(route('vacancies')); ?>"><?php echo e(__('Vacancies')); ?></a></li>
                    </ul>
                </div>
            </div>

            
            <div class="td_footer_col">
                <div class="td_footer_widget">
                    <h2 class="td_footer_widget_title td_fs_32 td_white_color td_medium td_mb_30">
                        <?php echo e(__('Subscribe now')); ?>

                    </h2>
                    <div class="td_newsletter td_style_1">
                        <p class="td_mb_20 td_opacity_7">
                            <?php echo e(__('Far far away, behind the word mountains, far from the Consonantia, there live the blind texts.')); ?>

                        </p>
                        <form class="td_newsletter_form" action="<?php echo e(route('subscribe')); ?>" method="POST"
                            id="newsletterForm">
                            <?php echo csrf_field(); ?>
                            <input type="email" name="email" class="td_newsletter_input"
                                placeholder="Email address" required>
                            <button type="submit" class="td_btn td_style_1 td_radius_30 td_medium">
                                <span class="td_btn_in td_white_color td_accent_bg">
                                    <span><?php echo e(__('Subscribe now')); ?></span>
                                </span>
                            </button>
                        </form>

                        <?php if(session('sub_ok')): ?>
                            <div class="alert alert-success mt-2"><?php echo e(session('sub_ok')); ?></div>
                        <?php endif; ?>

                        <script>
                            // İstəsən AJAX
                            document.getElementById('newsletterForm')?.addEventListener('submit', async function(e) {
                                if (!this.hasAttribute('data-ajax')) return;
                                e.preventDefault();
                                const formData = new FormData(this);
                                const res = await fetch(this.action, {
                                    method: 'POST',
                                    headers: {
                                        'X-Requested-With': 'XMLHttpRequest'
                                    },
                                    body: formData
                                });
                                const json = await res.json().catch(() => ({}));
                                alert(json?.message || 'Subscribed.');
                                this.reset();
                            });
                        </script>
                    </div>

                    
                    <?php if($footerGallery->count()): ?>
                        <div class="td_footer_gallery mt-4">
                            <h3 class="td_fs_20 td_white_color td_medium mb-3">
                            </h3>
                            <div class="row g-2">
                                <?php $__currentLoopData = $footerGallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-4">
                                        <a href="<?php echo e($g->image); ?>" target="_blank" rel="noopener noreferrer">
                                            <img src="<?php echo e($g->image); ?>"
                                                 alt="Gallery image <?php echo e($loop->iteration); ?>"
                                                 class="img-fluid"
                                                 style="
                                                    width: 100%;
                                                    height: 90px;
                                                    object-fit: contain;
                                                    background: #111;
                                                    padding: 4px;
                                                    border-radius: 10px;
                                                 ">
                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="td_footer_bottom td_fs_18">
        <div class="container">
            <div class="td_footer_bottom_in">
                <p class="td_copyright mb-0"><?php echo e(__('Copyright')); ?></p>
                <ul class="td_footer_widget_menu">
                    <li><a href="#"><?php echo e(__('Terms & Conditions')); ?></a></li>
                    <li><a href="#"><?php echo e(__('Privacy & Policy')); ?></a></li>
                </ul>
            </div>
        </div>
    </div>
</footer>
<!-- End Footer Section -->

<!-- Start Scroll Up Button -->
<div class="td_scrollup">
    <i class="fa-solid fa-arrow-up"></i>
</div>
<!-- End Scroll Up Button -->

<!-- Script -->
<script src="<?php echo e(asset('assets/js/jquery-3.7.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.slick.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/odometer.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/gsap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

</body>
</html>
<?php /**PATH /Users/karimovulvi/Desktop/hse.az/resources/views/partials/footer.blade.php ENDPATH**/ ?>