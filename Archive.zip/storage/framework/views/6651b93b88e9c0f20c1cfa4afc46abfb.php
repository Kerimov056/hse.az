
<?php
    use Carbon\Carbon;

    $now = Carbon::now('Asia/Baku');

    $isWeekday = $now->isWeekday(); // 1–5

    $start = $now->copy()->setTime(00, 30);
    $end   = $now->copy()->setTime(17, 0);

    $inBusinessHours = $now->between($start, $end);

    $showTawk = $isWeekday && $inBusinessHours;
?>

<?php if($showTawk): ?>
    
    <?php echo $__env->make('partials.tawk', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php else: ?>
    
    <?php if (isset($component)) { $__componentOriginal2f2d6d240d8b5bb0ae740a50d4cd2158 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2f2d6d240d8b5bb0ae740a50d4cd2158 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chat-widget','data' => ['label' => 'Mesaj göndərin','title' => 'Bizə yazın']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('chat-widget'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Mesaj göndərin','title' => 'Bizə yazın']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2f2d6d240d8b5bb0ae740a50d4cd2158)): ?>
<?php $attributes = $__attributesOriginal2f2d6d240d8b5bb0ae740a50d4cd2158; ?>
<?php unset($__attributesOriginal2f2d6d240d8b5bb0ae740a50d4cd2158); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2f2d6d240d8b5bb0ae740a50d4cd2158)): ?>
<?php $component = $__componentOriginal2f2d6d240d8b5bb0ae740a50d4cd2158; ?>
<?php unset($__componentOriginal2f2d6d240d8b5bb0ae740a50d4cd2158); ?>
<?php endif; ?>
<?php endif; ?>
<?php /**PATH /Users/karimovulvi/Desktop/hse.az/resources/views/partials/chat-switcher.blade.php ENDPATH**/ ?>