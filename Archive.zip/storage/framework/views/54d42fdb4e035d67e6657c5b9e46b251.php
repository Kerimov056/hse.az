<?php
    // Dəstəklənən dillər + flag url-lər
    $supportedLocales = [
        'az' => [
            'label' => 'AZ',
            'flag'  => asset('assets/img/flags/az.jpg'),
        ],
        'en' => [
            'label' => 'EN',
            'flag'  => asset('assets/img/flags/en.jpg'),
        ],
        'ru' => [
            'label' => 'RU',
            'flag'  => asset('assets/img/flags/ru.jpg'),
        ],
    ];

    $currentLocale = app()->getLocale();
    if (! array_key_exists($currentLocale, $supportedLocales)) {
        $currentLocale = 'en';
    }
?>

<div class="td_top_header td_heading_bg td_white_color">
    <div class="container" style="max-width:1400px!important;padding:0 16px!important;margin:0 auto!important;">
        <div class="td_top_header_in"
             style="display:flex!important;flex-wrap:wrap!important;align-items:center!important;justify-content:space-between!important;gap:8px!important;width:100%!important;">

            
            <div class="td_top_header_left"
                 style="flex:1 1 220px!important;min-width:0!important;overflow:hidden!important;">
                <div id="tickerLine"
                     style="position:relative!important;overflow:hidden!important;white-space:nowrap!important;font-size:14px!important;font-weight:600!important;color:#ffffff!important;">
                    <span id="tickerInner">
                        The Constitution of the Republic of Azerbaijan, Article 35/VI - Everyone has right to
                        work in safe and healthy workplace. Welcome to the first health, safety, environment
                        education platform of Azerbaijan.
                    </span>
                </div>
            </div>

            
            <div class="td_top_header_right"
                 style="display:flex!important;flex-wrap:wrap!important;align-items:center!important;justify-content:flex-end!important;gap:8px!important;flex:0 0 auto!important;">

                
                <div style="display:flex!important;align-items:center!important;gap:6px!important;flex-wrap:wrap!important;">
                    <?php if(auth()->guard()->guest()): ?>
                        <span style="font-size:14px!important;">
                            <a href="<?php echo e(route('auth.show', 'login')); ?>"
                               style="color:#ffffff!important;text-decoration:none!important;"><?php echo e(__('Sign in')); ?></a>
                            /
                            <a href="<?php echo e(route('auth.show', 'register')); ?>"
                               style="color:#ffffff!important;text-decoration:none!important;"><?php echo e(__('Sign up')); ?></a>
                        </span>
                    <?php endif; ?>

                    <?php if(auth()->guard()->check()): ?>
                        <span class="td_medium"
                              style="color:#ffffff!important;font-size:14px!important;"><?php echo e(Auth::user()->name); ?></span>
                        <form method="POST" action="<?php echo e(route('logout')); ?>" class="d-inline"
                              style="margin:0!important;">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="td_btn td_style_1 td_medium"
                                    style="border-radius:999px!important;border:none!important;padding:0px 14px!important;font-size:13px!important;">
                                <span class="td_btn_in td_white_color td_accent_bg">
                                    <span><?php echo e(__('Log out')); ?></span>
                                </span>
                            </button>
                        </form>
                    <?php endif; ?>
                </div>

                
                <div
                    style="
                        display:flex!important;
                        align-items:center!important;
                        gap:8px!important;
                        flex-wrap:nowrap!important;
                        padding:4px 10px!important;
                        border-radius:999px!important;
                        border:1px solid rgba(255,255,255,0.22)!important;
                        background:rgba(15,23,42,0.32)!important;
                        box-shadow:0 8px 20px rgba(15,23,42,0.35)!important;
                        backdrop-filter:blur(10px)!important;
                    ">
                    <select
                        id="topLangSelect"
                        style="
                            border:none!important;
                            outline:none!important;
                            background:transparent!important;
                            color:#ffffff!important;
                            font-size:13px!important;
                            font-weight:600!important;
                            padding:4px 8px 4px 0!important;
                            cursor:pointer!important;
                            min-width:60px!important;
                            border-right:1px solid rgba(255,255,255,0.25)!important;
                        ">
                        <?php $__currentLoopData = $supportedLocales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $conf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                value="<?php echo e($code); ?>"
                                data-flag="<?php echo e($conf['flag']); ?>"
                                data-url="<?php echo e(url($code)); ?>"
                                <?php if($code === $currentLocale): echo 'selected'; endif; ?>
                                style="color:#000!important;"
                            >
                                <?php echo e($conf['label']); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <button type="button"
                            onclick="document.querySelector('.td_search_tobble_btn')?.click()"
                            style="
                                width:30px!important;
                                height:30px!important;
                                border-radius:999px!important;
                                border:none!important;
                                background:rgba(255,255,255,0.16)!important;
                                display:flex!important;
                                align-items:center!important;
                                justify-content:center!important;
                                padding:0!important;
                                cursor:pointer!important;
                                flex-shrink:0!important;
                            ">
                        <img id="topLangFlag"
                             src="<?php echo e($supportedLocales[$currentLocale]['flag']); ?>"
                             alt="<?php echo e(strtoupper($currentLocale)); ?> flag"
                             style="width:18px!important;height:18px!important;display:block!important;border-radius:999px!important;object-fit:cover!important;">
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>


<script>
    window.addEventListener('load', function() {
        const line = document.getElementById('tickerLine');
        const inner = document.getElementById('tickerInner');
        if (!line || !inner) return;

        setTimeout(() => {
            const textWidth = inner.offsetWidth;
            const containerWidth = line.offsetWidth;
            if (textWidth <= containerWidth) return;

            let offset = 0;

            function step() {
                offset -= 1;
                if (Math.abs(offset) > textWidth) offset = containerWidth;
                inner.style.transform = 'translateX(' + offset + 'px)';
                inner.style.whiteSpace = 'nowrap';
                inner.style.display = 'inline-block';
                requestAnimationFrame(step);
            }

            requestAnimationFrame(step);
        }, 3000);
    });
</script>


<script>
    (function () {
        const select = document.getElementById('topLangSelect');
        const flagImg = document.getElementById('topLangFlag');
        if (!select || !flagImg) return;

        function updateFlag() {
            const opt = select.options[select.selectedIndex];
            if (!opt) return;
            const flagUrl = opt.getAttribute('data-flag');
            const code = opt.value || '';
            if (flagUrl) {
                flagImg.src = flagUrl;
                flagImg.alt = (code.toUpperCase() || 'LANG') + ' flag';
            }
        }

        // İlk load-da aktiv dili UI-da göstər
        updateFlag();

        select.addEventListener('change', function () {
            const opt = this.options[this.selectedIndex];
            if (!opt) return;

            // Bayraq dəyişsin
            updateFlag();

            // URL-ə keçid – hazırda /en, /az, /ru tipli prefix-lər
            const url = opt.getAttribute('data-url');
            if (url) {
                window.location.href = url;
            }
        });
    })();
</script>
<?php /**PATH /Users/karimovulvi/Desktop/hse.az/resources/views/partials/top-strip.blade.php ENDPATH**/ ?>