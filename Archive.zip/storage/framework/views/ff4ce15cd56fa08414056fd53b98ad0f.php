<?php
    use Illuminate\Support\Str;
    $q = $q ?? request('q');
?>

<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <!-- Page Heading (with settings-driven slider) -->
    <section id="topics-hero" class="td_page_heading td_center td_heading_bg text-center td_hobble">
        <?php
            // topics hero slider şəkilləri (settings → pages.heroes.topics.images)
            $topicSlides = (array) setting('pages.heroes.topics.images', []);
            $topicSlides = array_values(array_filter($topicSlides, fn($v) => is_string($v) && trim($v) !== ''));
            if (count($topicSlides) === 0) {
                $topicSlides = [asset('assets/img/others/page_heading_bg.jpg')];
            }
        ?>

        <style>
            /* ===== HERO SLIDER (topics) ===== */
            #topics-hero {
                position: relative;
                overflow: hidden;
            }

            #topics-hero .hero-slider {
                position: absolute;
                inset: 0;
                z-index: 0;
            }

            #topics-hero .hero-slide {
                position: absolute;
                inset: 0;
                background-size: cover;
                background-position: center;
                opacity: 0;
                transition: opacity .8s ease-in-out;
                will-change: opacity;
            }

            #topics-hero .hero-slide.is-active {
                opacity: 1;
            }

            #topics-hero .hero-overlay {
                position: absolute;
                inset: 0;
                background: linear-gradient(180deg, rgba(15, 23, 42, .25) 0%, rgba(15, 23, 42, .45) 100%);
                z-index: 1;
            }

            #topics-hero .td_page_heading_in {
                position: relative;
                z-index: 2;
            }
        </style>

        
        <div class="hero-slider" aria-hidden="true">
            <?php $__currentLoopData = $topicSlides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $src): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="hero-slide <?php echo e($i === 0 ? 'is-active' : ''); ?>" style="background-image:url('<?php echo e($src); ?>')">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="hero-overlay"></div>
        </div>

        <div class="container">
            <div class="td_page_heading_in">
                <h1 class="td_white_color td_fs_48 td_mb_10"><?php echo e(__("Topics")); ?></h1>
                <ol class="breadcrumb m-0 td_fs_20 td_opacity_8 td_semibold td_white_color">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo e(__("Home")); ?></a></li>
                    <li class="breadcrumb-item active"><?php echo e(__("Topics")); ?></li>
                </ol>
            </div>
        </div>

        
        <div class="td_page_heading_shape_1 position-absolute td_hover_layer_3"></div>
        <div class="td_page_heading_shape_2 position-absolute td_hover_layer_5"></div>
        <div class="td_page_heading_shape_3 position-absolute">
            <img src="<?php echo e(asset('assets/img/others/page_heading_shape_3.svg')); ?>" alt="">
        </div>
        <div class="td_page_heading_shape_4 position-absolute">
            <img src="<?php echo e(asset('assets/img/others/page_heading_shape_4.svg')); ?>" alt="">
        </div>
        <div class="td_page_heading_shape_5 position-absolute">
            <img src="<?php echo e(asset('assets/img/others/page_heading_shape_5.svg')); ?>" alt="">
        </div>
        <div class="td_page_heading_shape_6 position-absolute td_hover_layer_3"></div>
    </section>

    
    <script>
        (function() {
            const root = document.querySelector('#topics-hero .hero-slider');
            if (!root) return;

            const slides = Array.from(root.querySelectorAll('.hero-slide'));
            if (slides.length <= 1) return; // Tək şəkil üçün animasiya lazım deyil

            let idx = 0,
                timer = null;
            const INTERVAL = 2000; // 2s

            function show(i) {
                slides.forEach((s, k) => s.classList.toggle('is-active', k === i));
            }

            function next() {
                idx = (idx + 1) % slides.length;
                show(idx);
            }

            function start() {
                if (!timer) timer = setInterval(next, INTERVAL);
            }

            function stop() {
                if (timer) {
                    clearInterval(timer);
                    timer = null;
                }
            }

            start();

            const hero = document.getElementById('topics-hero');
            hero.addEventListener('mouseenter', stop);
            hero.addEventListener('mouseleave', start);

            document.addEventListener('visibilitychange', () => {
                if (document.hidden) stop();
                else start();
            });
        })();
    </script>

    <section>
        <div class="td_height_120 td_height_lg_80"></div>
        <div class="container">

            
            <div id="topics-search" class="td_mb_30">
                <form action="<?php echo e(route('topices')); ?>" method="GET" role="search" aria-label="Topics search">
                    <div class="input-group" style="max-width:720px;margin:0 auto;">
                        <input type="text" name="q" class="form-control"
                            placeholder="Search topics by name or description..." value="<?php echo e($q); ?>"
                            autocomplete="off">
                        <?php if($q): ?>
                            <a href="<?php echo e(route('topices')); ?>" class="btn btn-outline-secondary">Clear</a>
                        <?php endif; ?>
                        <button class="btn btn-primary" type="submit"><?php echo e(__("Axtar")); ?></button>
                    </div>
                </form>
            </div>

            <?php if($topices->count() > 0): ?>
                <div id="topics-grid" class="row td_gap_y_30">
                    <?php $__currentLoopData = $topices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6">
                            <div class="td_card td_style_1 td_radius_5">
                                <a href="<?php echo e(route('topices-details', $t->id)); ?>"
                                    class="td_card_thumb td_mb_30 d-block position-relative">
                                    <img src="<?php echo e($t->imageUrl ?: asset('assets/img/placeholder/placeholder-800x500.jpg')); ?>"
                                        alt="<?php echo e($t->name); ?>">
                                    <i class="fa-solid fa-arrow-up-right-from-square"></i>
                                    <span class="td_card_location td_medium td_white_color td_fs_18">
                                        <svg width="16" height="22" viewBox="0 0 16 22" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M8.0004 0.5C3.86669 0.5 0.554996 3.86526 0.500458 7.98242C0.48345 9.42271 0.942105 10.7046 1.56397 11.8232C2.76977 13.9928 4.04435 16.8182 5.32856 19.4639C5.9286 20.7002 6.89863 21.5052 8.0004 21.5C9.10217 21.4948 10.0665 20.6836 10.6575 19.4404C11.9197 16.7856 13.1685 13.9496 14.4223 11.835C15.1136 10.6691 15.4653 9.3606 15.4974 8.01758C15.5966 3.86772 12.1342 0.5 8.0004 0.5Z"
                                                fill="currentColor" />
                                        </svg>
                                        <?php echo e($t->category->name ?? ($t->category ?? 'Topic')); ?>

                                    </span>
                                </a>

                                <div class="td_card_info">
                                    <div class="td_card_info_in">
                                        <div class="td_mb_30">
                                            <ul class="td_card_meta td_mp_0 td_fs_18 td_medium td_heading_color">
                                                <li>
                                                    <svg class="td_accent_color" width="22" height="24"
                                                        viewBox="0 0 22 24" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M17.3308 11.7869H19.0049C19.3833 11.7869 19.6913 11.479 19.6913 11.1005V9.42642C19.6913 9.04795 19.3833 8.74003 19.0049 8.74003H17.3308C16.9523 8.74003 16.6444 9.04795 16.6444 9.42642V11.1005C16.6444 11.479 16.9523 11.7869 17.3308 11.7869Z"
                                                            fill="currentColor" />
                                                    </svg>
                                                    <span><?php echo e(optional($t->updated_at)->format('M d, Y')); ?></span>
                                                </li>
                                                <li>
                                                    <svg class="td_accent_color" width="24" height="24"
                                                        viewBox="0 0 24 24" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"
                                                            stroke="currentColor" stroke-width="1.6" />
                                                        <circle cx="12" cy="12" r="3" stroke="currentColor"
                                                            stroke-width="1.6" />
                                                    </svg>
                                                    <span><?php echo e(number_format($t->views ?? 0)); ?> views</span>
                                                </li>
                                            </ul>
                                        </div>

                                        <h2 class="td_card_title td_fs_32 td_semibold td_mb_20">
                                            <a href="<?php echo e(route('topices-details', $t->id)); ?>"><?php echo e($t->name); ?></a>
                                        </h2>

                                        <?php $desc = strip_tags($t->description ?? ''); ?>
                                        <p class="td_mb_30 td_fs_18"><?php echo e($desc ? Str::limit($desc, 180) : ' '); ?></p>

                                        <a href="<?php echo e(route('topices-details', $t->id)); ?>"
                                            class="td_btn td_style_1 td_radius_10 td_medium">
                                            <span class="td_btn_in td_white_color td_accent_bg">
                                                <span>Learn More</span>
                                                <svg width="19" height="20" viewBox="0 0 19 20" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M15.1575 4.34302L3.84375 15.6567" stroke="currentColor"
                                                        stroke-width="1.5" />
                                                </svg>
                                            </span>
                                        </a>
                                        <?php if(!empty($t->courseUrl)): ?>
                                            <a href="<?php echo e($t->courseUrl); ?>" target="_blank" rel="noopener"
                                                class="td_btn td_style_2 td_radius_10 td_medium">
                                                <span
                                                    class="td_btn_in td_heading_color td_white_bg"><span>Visit</span></span>
                                            </a>
                                        <?php endif; ?>

                                    </div>
                                </div>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <?php if(method_exists($topices, 'links')): ?>
                    <div class="td_height_60 td_height_lg_40"></div>
                    <div class="text-center"><?php echo e($topices->appends(['q' => $q])->links()); ?></div>
                <?php endif; ?>
            <?php else: ?>
                <div class="text-center td_opacity_8">
                    <?php if($q): ?>
                        No topics found for “<?php echo e($q); ?>”.
                        <div class="td_height_10"></div>
                        <a href="<?php echo e(route('topices')); ?>" class="td_btn td_style_2 td_radius_10 td_medium">
                            <span class="td_btn_in td_heading_color td_white_bg"><span>Show All</span></span>
                        </a>
                    <?php else: ?>
                        No topics added yet.
                    <?php endif; ?>
                </div>
            <?php endif; ?>

        </div>
        <div class="td_height_120 td_height_lg_80"></div>
    </section>

    
    <?php if (isset($component)) { $__componentOriginald6dcc3967e783dd246a958dd7fc8dd97 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald6dcc3967e783dd246a958dd7fc8dd97 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.section-guide','data' => ['page' => 'topices']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section-guide'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['page' => 'topices']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald6dcc3967e783dd246a958dd7fc8dd97)): ?>
<?php $attributes = $__attributesOriginald6dcc3967e783dd246a958dd7fc8dd97; ?>
<?php unset($__attributesOriginald6dcc3967e783dd246a958dd7fc8dd97); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald6dcc3967e783dd246a958dd7fc8dd97)): ?>
<?php $component = $__componentOriginald6dcc3967e783dd246a958dd7fc8dd97; ?>
<?php unset($__componentOriginald6dcc3967e783dd246a958dd7fc8dd97); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/karimovulvi/Desktop/hse.az/resources/views/educve/topices.blade.php ENDPATH**/ ?>