@include('partials.header')

@yield('content')

@include('partials.chat-switcher')
@include('partials.footer')
