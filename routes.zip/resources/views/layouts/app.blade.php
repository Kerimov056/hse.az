
@include('partials.header')

@yield('content')
<x-chat-widget label="Mesaj göndərin" title="Bizə yazın" />
@include('partials.footer')
